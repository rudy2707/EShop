// PerspectiveView_mvpMatrix.js (c) 2012 matsuda
// Vertex shader program

var canvas;
var gl;

var shaderProgram;
var shaders = [];
var meshes = [];

function getFileContent(filePath)
{
	var request = new XMLHttpRequest();
	request.open("GET", filePath, false);  // `false` makes the request synchronous
	request.send(null);

	if (request.status === 200)
	{
		console.log(request.responseText);
		return request.responseText;
	}
}

function initShader(vertexSource, fragmentSource)
{
	var vertexShader = gl.createShader(gl.VERTEX_SHADER);
	gl.shaderSource(vertexShader, vertexSource);
	gl.compileShader(vertexShader);

	if(!gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS))
	{
		console.log("Failed to compile vertex shader");
		return;
	}

	var fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
	gl.shaderSource(fragmentShader, fragmentSource);
	gl.compileShader(fragmentShader);

	if(!gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS))
	{
		console.log("Failed to compile fragment shader");
		return;
	}

	var shaderProgram = gl.createProgram();
	gl.attachShader(shaderProgram, vertexShader);
	gl.attachShader(shaderProgram, fragmentShader);
	gl.linkProgram(shaderProgram);

	if(!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS))
	{
		console.log("Failed to link shader program");
		return ;
	}

	return shaderProgram;
}


function init()
{
	canvas = document.getElementById('webgl');
	gl = getWebGLContext(canvas);

	if(!gl)
	{
		console.log('Failed to get the rendering context for WebGL');
		return;
	}

	var vShaderSource = getFileContent("Shaders/Color3D.vert");
	var fShaderSource = getFileContent("Shaders/Color3D.frag");
	
	shaderProgram = initShader(vShaderSource, fShaderSource);

	
	gl.useProgram(shaderProgram);
	
	meshes.push(initMeshFromObj("Cube"));
	//meshes.push(initMeshFromObj("BananaGroup0"));
	//meshes.push(initMeshFromObj("BananaGroup"));
	//meshes.push(initMeshFromObj("Suzanne"));
	//meshes.push(initMeshFromObj("trotteuse"));
	//meshes.push(initCube());
	meshes.push(initSphere());
	//handleLoadedObject()

	gl.enable(gl.DEPTH_TEST);
	gl.clearColor(0, 0, 0, 1.0);
}



function initMeshFromObj(meshName)
{
	var mesh = {};
	var objFileName = "Meshes/" + meshName + ".obj";
	var mtlFileName = "Meshes/" + meshName + ".mtl";

	var objFileLines = getFileContent(objFileName).split("\n");
	//var mtlFileLines = getFileContent(mtlFileName).split("\n");

	var vertices = [];
	var tmpVertices = [];
	var colors = [];
	var normals = [];
	var indices = [];

	var tmpNormal = [];
	var iNormal = [];

	var faces = [];
	//var face = {vertex:[], texture:[], normal:[]};

	for(var i = 0; i < objFileLines.length; i++)
	{
		if(objFileLines[i][0] != '#')
		{
			data = objFileLines[i].split(" ");

			if(data[0] == "v")
			{
				tmpVertices.push([data[1], data[2], data[3]]);

				colors.push(1.0);
				colors.push(0.8);
				colors.push(0.0);
				colors.push(1.0);
			}
			else if(data[0] == "vn")
			{
				tmpNormal.push([data[1], data[2], data[3]]);
			}
			else if(data[0] == "f")
			{
				
				data.shift();
				data = data.join("/");
				var terms = data.split("/");

				nData = Math.floor(terms.length / 3);

				var face = {};
				face.vertices = [];
				face.textures = [];
				face.normals = [];
				
				if(nData == 4)
				{
					face.vertices.push(terms[0 * 3] -1);
					face.vertices.push(terms[1 * 3] -1);
					face.vertices.push(terms[2 * 3] -1);
					face.vertices.push(terms[0 * 3] -1);
					face.vertices.push(terms[3 * 3] -1);
					face.vertices.push(terms[2 * 3] -1);

					face.textures.push(terms[0 * 3 + 1] -1);
					face.textures.push(terms[1 * 3 + 1] -1);
					face.textures.push(terms[2 * 3 + 1] -1);
					face.textures.push(terms[0 * 3 + 1] -1);
					face.textures.push(terms[3 * 3 + 1] -1);
					face.textures.push(terms[2 * 3 + 1] -1);

					face.normals.push(terms[0 * 3 + 2] -1);
					face.normals.push(terms[1 * 3 + 2] -1);
					face.normals.push(terms[2 * 3 + 2] -1);
					face.normals.push(terms[0 * 3 + 2] -1);
					face.normals.push(terms[3 * 3 + 2] -1);
					face.normals.push(terms[2 * 3 + 2] -1);

					/*iNormal.push(terms[0 * 3 + 2] - 1);
					iNormal.push(terms[1 * 3 + 2] - 1);
					iNormal.push(terms[2 * 3 + 2] - 1);
					iNormal.push(terms[0 * 3 + 2] - 1);
					iNormal.push(terms[3 * 3 + 2] - 1);
					iNormal.push(terms[2 * 3 + 2] - 1);*/

					/*indices.push(terms[0 * 3] -1);
					indices.push(terms[1 * 3] -1);
					indices.push(terms[2 * 3] -1);
					indices.push(terms[0 * 3] -1);
					indices.push(terms[3 * 3] -1);
					indices.push(terms[2 * 3] -1);*/

					/*iNormal.push(terms[0 * 3 + 2] - 1);
					iNormal.push(terms[1 * 3 + 2] - 1);
					iNormal.push(terms[2 * 3 + 2] - 1);
					iNormal.push(terms[0 * 3 + 2] - 1);
					iNormal.push(terms[3 * 3 + 2] - 1);
					iNormal.push(terms[2 * 3 + 2] - 1);*/
					
				}	
				else if(nData == 3)
				{
					face.vertices.push(terms[0 * 3] - 1);
					face.vertices.push(terms[1 * 3] - 1);
					face.vertices.push(terms[2 * 3] - 1);

					face.textures.push(terms[0 * 3 + 1] - 1);
					face.textures.push(terms[1 * 3 + 1] - 1);
					face.textures.push(terms[2 * 3 + 1] - 1);

					face.normals.push(terms[0 * 3 + 2] - 1);
					face.normals.push(terms[1 * 3 + 2] - 1);
					face.normals.push(terms[2 * 3 + 2] - 1);


					/*indices.push(terms[0 * 3] -1);
					indices.push(terms[1 * 3] -1);
					indices.push(terms[2 * 3] -1);*/

					/*iNormal.push(terms[0 * 3 + 2] - 1);
					iNormal.push(terms[1 * 3 + 2] - 1);
					iNormal.push(terms[2 * 3 + 2] - 1);*/
				}

				faces.push(face);
			}
		}
	}

	var counter = 0;
	for(var i = 0; i < faces.length; i++)
	{
		for(var j = 0; j < faces[i].vertices.length; j++)
		{
			indices.push(counter++);
			indices.push(counter++);
			indices.push(counter++);

			vertices.push(tmpVertices[faces[i].vertices[j]][0]);
			vertices.push(tmpVertices[faces[i].vertices[j]][1]);
			vertices.push(tmpVertices[faces[i].vertices[j]][2]);

			normals.push(tmpNormal[faces[i].normals[j]][0]);
			normals.push(tmpNormal[faces[i].normals[j]][1]);
			normals.push(tmpNormal[faces[i].normals[j]][2]);
		}
	}

	console.log(vertices.length);
	console.log(indices.length)
	console.log(normals.length)

	/*for(var i = 0; i < tmpVertices.length; i++)
	{
		vertices.push(tmpVertices[i][0]);
		vertices.push(tmpVertices[i][1]);
		vertices.push(tmpVertices[i][2]);
	}

	for(var i = 0; i < iNormal.length; i++)
	{
		if(iNormal[i] < tmpNormal.length)
		{
			normals.push(tmpNormal[iNormal[i]][0]);
			normals.push(tmpNormal[iNormal[i]][1]);
			normals.push(tmpNormal[iNormal[i]][2]);
		}
	}*/
	//console.log(normals);
	//console.log(indices);

	mesh.verticesBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.verticesBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

	mesh.colorsBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.colorsBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

	mesh.normalsBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalsBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);

	mesh.indicesBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indicesBuffer);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), gl.STATIC_DRAW);

	//mesh.size = indices.length;

	//console.log(mesh);

	return mesh;
}

function initSphere()
{
	var slices = 36;
	var stacks = 36;

	var vertices = [];
	var colors = [];
	var normals = [];
	var indices = [];

	var mesh = {};
	
	var vector = new Vector3();


	for(var i = 0; i <= slices; i++)
	{
		for(var j = 0; j <= stacks; j++)
		{
			vertex = {};
			var phi = (j / stacks) * Math.PI;
			var theta = (i / slices) * 2 * Math.PI;
			
			var x = Math.sin(phi) * Math.cos(theta);
			var y = -Math.cos(phi);
			var z = Math.sin(phi) * Math.sin(theta);
			
			vector.elements = [x, y, z];
			vector.normalize();

			vertices.push(x);
			vertices.push(y);
			vertices.push(z);
		
			normals.push(vector.elements[0]);
			normals.push(vector.elements[1]);
			normals.push(vector.elements[2]);

			//if((i + j) %2)
			if(j %2)
			{
				colors.push(1.0);
				colors.push(1.0);
				colors.push(1.0);
			}
			else
			{
				colors.push(0.0);
				colors.push(0.0);
				colors.push(0.0);
			}

			colors.push(1.0);
		}
	}

	mesh.verticesBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.verticesBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

	mesh.colorsBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.colorsBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

	mesh.normalsBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalsBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);

	for(var i = 0; i < slices; i++)
	{
		for(var j = 0; j < stacks; j++)
		{
			var bottomRight = i * (stacks + 1) + j;
			var topRight = bottomRight + 1;
			var topLeft = topRight + stacks + 1;
			var bottomLeft = bottomRight + stacks + 1;

			indices.push(bottomRight);
			indices.push(topRight);
			indices.push(topLeft);

			indices.push(topLeft);
			indices.push(bottomLeft);
			indices.push(bottomRight);
		}
	}
	
	mesh.indicesBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indicesBuffer);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), gl.STATIC_DRAW);

	mesh.size = indices.length;

	return mesh;
}


function initCube()
{
	var mesh = {};

	var vertices = [
	// Front face
	-1.0, -1.0,  1.0,
	1.0, -1.0,  1.0,
	1.0,  1.0,  1.0,
	-1.0,  1.0,  1.0,

	// Back face
	-1.0, -1.0, -1.0,
	-1.0,  1.0, -1.0,
	1.0,  1.0, -1.0,
	1.0, -1.0, -1.0,

	// Top face
	-1.0,  1.0, -1.0,
	-1.0,  1.0,  1.0,
	1.0,  1.0,  1.0,
	1.0,  1.0, -1.0,

	// Bottom face
	-1.0, -1.0, -1.0,
	1.0, -1.0, -1.0,
	1.0, -1.0,  1.0,
	-1.0, -1.0,  1.0,

	// Right face
	1.0, -1.0, -1.0,
	1.0,  1.0, -1.0,
	1.0,  1.0,  1.0,
	1.0, -1.0,  1.0,

	// Left face
	-1.0, -1.0, -1.0,
	-1.0, -1.0,  1.0,
	-1.0,  1.0,  1.0,
	-1.0,  1.0, -1.0
	];

	var normals = [	0, 0, 1,
					0, 0, 1,
					0, 0, 1,
					0, 0, 1,

					0, 0, -1,
					0, 0, -1,
					0, 0, -1,
					0, 0, -1,

					0, 1, 0,
					0, 1, 0,
					0, 1, 0,
					0, 1, 0,

					0, -1, 0,
					0, -1, 0,
					0, -1, 0,
					0, -1, 0,

					1, 0, 0,
					1, 0, 0,
					1, 0, 0,
					1, 0, 0,

					-1, 0, 0,
					-1, 0, 0,
					-1, 0, 0,
					-1, 0, 0
					];

	mesh.verticesBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.verticesBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

  	var colors = [
    [1.0,  1.0,  1.0,  1.0],    // Front face: white
    [1.0,  0.0,  0.0,  1.0],    // Back face: red
    [0.0,  1.0,  0.0,  1.0],    // Top face: green
    [0.0,  0.0,  1.0,  1.0],    // Bottom face: blue
    [1.0,  1.0,  0.0,  1.0],    // Right face: yellow
    [1.0,  0.0,  1.0,  1.0]     // Left face: purple
	];

	var generatedColors = [];

	for(j = 0; j < 6; j++)
	{
    	var c = colors[j];

		for (var i = 0; i < 4; i++)
		{
			generatedColors = generatedColors.concat(c);
		}
	}

	mesh.normalsBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalsBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);


	mesh.colorsBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.colorsBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(generatedColors), gl.STATIC_DRAW);

	var indices = [
	0,  1,  2,      0,  2,  3,    // front
	4,  5,  6,      4,  6,  7,    // back
	8,  9,  10,     8,  10, 11,   // top
	12, 13, 14,     12, 14, 15,   // bottom
	16, 17, 18,     16, 18, 19,   // right
	20, 21, 22,     20, 22, 23    // left
	]

	mesh.indicesBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indicesBuffer);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), gl.STATIC_DRAW);

	mesh.size = 36;

		
	return mesh;
}

function sendMat4(name, matrix)
{
	var location = gl.getUniformLocation(shaderProgram, name);
	if(!location)
	{
		console.log("Failed to get the storage location of " + name);
		return;
	}

	gl.uniformMatrix4fv(location, false, matrix.elements);
}

var angle = 0;
function drawMesh(mesh)
{

	var model = new Matrix4();
	var view = new Matrix4();
	var projection = new Matrix4(); 

	view.setLookAt(3, 3, 0, 0, 0, 0, 0, 1, 0);
	projection.setPerspective(95, canvas.width / canvas.height, 1, 100);
	
	model.setRotate(angle, 0, 1, 0);

	/*if(angle %2)
	model.translate(3.0, 0.0, 0.0);*/

	/*model.invert();
	model.transpose();*/

	sendMat4("model", model);
	sendMat4("view", view);
	sendMat4("projection", projection);
	
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.verticesBuffer);
	var in_Vertex = gl.getAttribLocation(shaderProgram, "in_Vertex");
	gl.enableVertexAttribArray(0);
	gl.vertexAttribPointer(in_Vertex, 3, gl.FLOAT, false, 0, 0);

	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.colorsBuffer);
	var in_Color = gl.getAttribLocation(shaderProgram, "in_Color");
	gl.enableVertexAttribArray(1);
	gl.vertexAttribPointer(in_Color, 4, gl.FLOAT, false, 0, 0);

	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalsBuffer);
	var in_Normal = gl.getAttribLocation(shaderProgram, "in_Normal");
	gl.enableVertexAttribArray(2);
	gl.vertexAttribPointer(in_Normal, 3, gl.FLOAT, false, 0, 0);

	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indicesBuffer);

	gl.drawElements(gl.TRIANGLES, mesh.size, gl.UNSIGNED_SHORT, 0);

	angle++;
}

function mainLoop()
{
	gl.clear(gl.COLOR_BUFFER_BIT);

	drawMesh(meshes[0]);
	//drawMesh(meshes[1]);
	//drawMesh(meshes[2]);

	//requestAnimationFrame(mainLoop);
}

function start()
{
	init();


	mainLoop();
}
